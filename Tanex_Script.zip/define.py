import re

class tanex_script_error(Exception):
    # Tanex Script 自定义异常类
    pass

def output_message(message_list: list, error: bool = True, color: str = '\033[0m'):
    if message_list:

        def get_content(value, level = 0):
            content = ''
            for s in value:
                if isinstance(s, str):
                    content += f'\n{level * "  "}·{s}'
                else:
                    content += get_content(s, level + 1)
            return content

        content = get_content(message_list)
        print(f'\n{color}{content}\033[0m\n')
    if error:
        exit(1)

def warning(warning_list: list):
    output_message(['警告', warning_list], False, '\033[38;5;208m')

def error(error_list: list):
    output_message(['错误', error_list], True, '\033[31m')

def hex_to_ansi(hex_color):
    pattern = r'^#([0-9a-fA-F]{3}){1,2}$'
    if not re.match(pattern, hex_color):
        error([f'无效的十六进制颜色代码: {hex_color}'])
    if len(hex_color) == 4:
        hex_color = '#' + ''.join([c * 2 for c in hex_color[1:]])
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    return f'\033[38;2;{r};{g};{b}m'

def tanex_script_output(string):
    try:
        from inout import tanex_script_output as inout_output
        inout_output(string)
    except tanex_script_error as e:
        error([str(e)])
    except Exception:
        error([f'输出处理错误'])
