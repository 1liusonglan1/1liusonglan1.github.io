# Tanex Script 运行时执行器
# 完整的运行时环境，支持 AST 解释执行、变量存储、错误处理、警告系统、输出功能等

import json
import os
from typing import Any, Dict 
from define import *

# Tanex Script 运行时执行器异常类
class run_time_error(tanex_script_error):
    # 运行时错误异常类
    pass

# 类型定义
ast = Dict[str, Any]

# Tanex Script 运行时执行器主类
class tanex_script_run_time:
    def __init__(self, path: str):
        # 初始化运行时环境，加载AST并设置变量存储
        path = os.path.splitext(path)[0] + '.tscc'
        if not os.path.exists(path):
            error([f'编译文件 {path} 不存在'])
        try:
            with open(path, 'r', encoding = 'utf-8') as file:
                self.ast = json.loads(file.read())
        except Exception:
            exit(1)
        self.name = []

    def assignment(self, code_ast: ast) -> ast:
        append_value: ast = {}
        name = code_ast['assignment']['left']
        value = code_ast['assignment']['right']
        operator = code_ast['assignment']['operator']
        if operator != '=':
            append_value = self.run_code({'binary': [operator[0], self.name[self.name.index(name)], value]})
            if name not in self.name:
                self.error(f'{name} 并未赋值，不可进行复式赋值')
        else:
            append_value = self.run_code(value)
        return append_value

    def error(self, error: str):
        raise run_time_error(error)

    def run(self):
        self.run_code(self.ast)

    def run_code(self, code_ast: ast) -> ast:
        if list(code_ast.keys())[0] == 'assignment':
            return self.assignment(code_ast)
        return {}

def run_code(path: str):
    try:
        run_time = tanex_script_run_time(path)
        run_time.run()
    except Exception as e:
        error([f'运行时环境启动失败: {str(e)}'])

# 导出函数
__all__ = ['run_code']