import re
from define import tanex_script_error
from typing import List, Dict, Any, Tuple
from define import *
import os
import json

# Tanex Script 解释器 - 用于解析和执行 Tanex Script 语言
# 主要功能：词法分析、语法分析、AST 生成

class syntax_error(tanex_script_error):
    # 语法错误异常类
    pass

class parse_error(tanex_script_error):
    def __init__(self, message: str, line: int):
        super().__init__(f'在第 {line} 句非注释的代码出现了语法错误: {message}')

class lexer:
    def __init__(self):
        self.operators = [
            '=', '+=', '-=', '*=', '/=', 
            '%=', '^=', '&=', '|=',
            '==', '!=',
            '||',
            '&&',
            '<', '<=', '>', '>=',
            '\\', '%',
            '^',
            '!', '+', '-',
            '*', '/',
            '@', '$', '$$',
            '**', '***',
            '~',
            '.',
            '|', '?', ':',
            '->', '<-',
            '<<', '>>',
            '&',
            '::'
        ]
        self.special_operators = [
            '***', '**', '&&', '||', '+=', '-=', '*=', '/=', '%=', '^=', '<-',
            '&=', '|=', '==', '!=', '<=', '>=', '?', '|', '->', '<<', '>>', '::', '$$'
        ]
        # 所有合法的运算符和边界字符
        self.boundary_chars = ['(', ')', '[', ']', '{', '}', ';', ',', '!']

    def _error(self, message: str):
        # 解释器错误处理方法
        raise syntax_error(message)

    def _tokenize(self, code: str) -> List[str]:
        # 词法分析器
        # 将代码分解为 token 序列
        if not code:
            return []
        tokens = []
        i = 0
        n = len(code)
        while i < n:
            if code[i].isspace():
                i += 1
                continue
            if code[i] == '"':
                start = i
                i += 1
                while i < n:
                    if code[i] == '\\' and i + 1 < n:
                        i += 2
                    elif code[i] == '"':
                        i += 1
                        break
                    else:
                        i += 1
                if i > n or (i <= n and code[i-1] != '"'):
                    self._error(f'未闭合的字符串: {code[start:i]}')
                tokens.append(code[start:i])
                continue
            if code[i] == "'":
                start = i
                i += 1
                has_dot = False
                valid = True
                while i < n:
                    if code[i] == "'":
                        i += 1
                        break
                    elif code[i] == '.':
                        if has_dot:
                            valid = False
                            break
                        has_dot = True
                        i += 1
                    elif code[i].isdigit():
                        i += 1
                    else:
                        valid = False
                        break
                if not valid:
                    self._error(f'数字格式错误: {code[start:i]}')
                if i > n or (i <= n and code[i-1] != "'"):
                    self._error(f'未闭合的数字: {code[start:i]}')
                tokens.append(code[start:i])
                continue
            if code[i] == '`':
                start = i
                i += 1
                while i < n and code[i] != '`':
                    i += 1
                if i >= n or code[i] != '`':
                    self._error(f'未闭合的地址: {code[start:i]}')
                i += 1
                tokens.append(code[start:i])
                continue
            if code[i] == '#':
                start = i
                i += 1
                while i < n:
                    if code[i] == '\\' and i + 1 < n:
                        i += 2
                    elif code[i] == '#':
                        i += 1
                        break
                    else:
                        i += 1
                if i > n or (i <= n and code[i-1] != '#'):
                    self._error(f'未闭合的注释: {code[start:i]}')
                continue
            op_match = None
            for op in sorted(self.special_operators, key = len, reverse = True):
                op_len = len(op)
                if i + op_len <= n and code[i:i + op_len] == op:
                    tokens.append(op)
                    i += op_len
                    op_match = True
                    break
            if op_match:
                continue
            if code[i] in self.operators or code[i] in self.boundary_chars:
                tokens.append(code[i])
                i += 1
                continue
            if re.match(r'(?:[a-zA-Z0-9_]|[\u0370-\u03ff]|[\u0400-\u04ff]|[\u0590-\u05ff]|[\u0600-\u06ff]|[\u0e00-\u0e7f]|[\u0900-\u097f]|[\u4e00-\u9fff]|[\u3040-\u309f]|[\u30a0-\u30ff]|[\uac00-\ud7af]|[\u00c0-\u024f]|[\u1e00-\u1eff]|[\u2c60-\u2c7f]|[\ua720-\ua7ff])', code[i]):
                start = i
                while i < n and re.match(r'(?:[a-zA-Z0-9_]|[\u0370-\u03ff]|[\u0400-\u04ff]|[\u0590-\u05ff]|[\u0600-\u06ff]|[\u0e00-\u0e7f]|[\u0900-\u097f]|[\u4e00-\u9fff]|[\u3040-\u309f]|[\u30a0-\u30ff]|[\uac00-\ud7af]|[\u00c0-\u024f]|[\u1e00-\u1eff]|[\u2c60-\u2c7f]|[\ua720-\ua7ff])', code[i]):
                    i += 1
                tokens.append(code[start:i])
                continue
            self._error(f'无法识别的字符: “{code[i]}”')
        return tokens

    def _first_validate_syntax(self, code: str):
        # 验证语法
        # 验证括号匹配
        stack = []
        bracket_pairs = {'(': ')', '[': ']', '{': '}'}
        for i, char in enumerate(code):
            line = code[:i].count('\n') + 1
            col = i - code.rfind('\n', 0, i)
            if char in bracket_pairs:
                stack.append((char, line, col))
            elif char in bracket_pairs.values():
                if not stack:
                    self._error(f'第 {line} 行, 第 {col} 列: 多余的闭合括号 “{char}”')
                open_bracket, open_line, open_col = stack.pop()
                if bracket_pairs[open_bracket] != char:
                    self._error(f'第 {open_line} 行, 第 {open_col} 列: 括号不匹配 “{open_bracket}” 与 “{char}”')
        if stack:
            open_bracket, open_line, open_col = stack[0]
            self._error(f'第 {open_line} 行, 第 {open_col} 列: 未闭合的括号 “{open_bracket}”')
        code_list = code.split('\n')
        for i in range(len(code_list)):
            code_list[i] += ' '
        code = ''.join(code_list)
        in_string, in_annotation, escape, next_char_semicolon = False, False, False, False
        for char in code:
            if char == '\\' and in_string:
                escape = not escape
            if char == '"' and not in_annotation and not escape:
                in_string = not in_string
            if char != ';' and next_char_semicolon:
                self._error(f'表达式未以分号结尾')
                next_char_semicolon = False
            if next_char_semicolon:
                next_char_semicolon = False
            if char == '#' and not in_string:
                if in_annotation:
                    next_char_semicolon = True
                in_annotation = not in_annotation
        if in_string:
            self._error(f'字符串未闭合')
        if in_annotation:
            self._error(f'注释未闭合')

    def _second_validate_syntax(self, tokens):
        # 二次检查
        if tokens[-1] != ';':
            self._error(f'表达式未以分号结尾')
        # 定义运算符
        operators = [
            '=', '+=', '-=', '*=', '/=', '%=', '^=', '&=', '|=',
            '||', '&&', '==', '!=', '<', '<=', '>', '>=',
            '+', '-', '/', '\\', '%', '^', '&', '$$',
            '@', '$', '*', '**', '***', ',', '.', ';', '~', '!', '::',
            '?', '|', ':', '->', '<<', '>>', 'and', 'or', 'is', 'not',
            'return', '<-', 'in'
        ]
        # 定义一元运算符
        unary_operators = ['**', '***', '~', '->', 'return', '$', '!', '<-']
        # 定义括号
        opening_brackets = ['(', '[', '{']
        closing_brackets = [')', ']', '}']
        # 规则1: 后括号后必须是符号
        for i in range(len(tokens) - 1):
            current = tokens[i]
            next_token = tokens[i + 1]
            # 如果当前token是右括号
            if current in closing_brackets:
            # 检查下一个token是否是符号
                if next_token not in operators and next_token not in ('(', ')', '[', ']', '{', '}'):
                    self._error(f'右括号 {current} 后必须是符号，但遇到了 {next_token}')
                # 右括号后不能是 code 类型值，是语法错误
                if next_token == '{':
                    self._error(f'右括号 {current} 后不能是 code 类型值')
                if current == '}' and next_token in ('(', ']', '}'):
                    self._error(f'code 类型值后不能是括号 {next_token}')
        # 规则2: 值与值之间不能无间隔
        for i in range(len(tokens) - 1):
            current = tokens[i]
            next_token = tokens[i + 1]
            # 如果当前token是值（非运算符、非括号）
            if current not in operators and current not in opening_brackets and current not in closing_brackets:
                # 下一个token也是值
                if next_token not in operators and next_token not in opening_brackets and next_token not in closing_brackets:
                    self._error(f'{current} 和 {next_token} 之间缺少间隔符号')
        # 规则3: 一元运算符前面不能是值
        for i in range(len(tokens)):
            current = tokens[i]
            # 如果当前token是一元运算符
            if current in unary_operators:
                # 检查前一个token是否存在且是值
                if i > 0:
                    prev_token = tokens[i - 1]
                    # 如果前一个token是值（非运算符、非括号）
                    if prev_token not in operators and prev_token not in opening_brackets and prev_token not in closing_brackets:
                        self._error(f'一元运算符 {current} 前面不可以是值 {prev_token}')
        # 规则4: 验证三目运算符语法
        i = 0
        while i < len(tokens):
            current = tokens[i]
            # 检查三目运算符 '?' / '|'
            if current in ['?', '|']:
                # '?' / '|' 前面必须是表达式（不能是运算符或括号）
                if i == 0:
                    self._error(f'三目运算符 “?” / “|” 前面不能为空')
                prev_token = tokens[i - 1]
                if prev_token in operators or prev_token in opening_brackets:
                    self._error(f'三目运算符 “?” / “|” 前面不能是运算符或左括号 “{prev_token}”')
                # 寻找对应的 ':'
                colon_found = False
                j = i + 1
                bracket_depth = 0
                paren_depth = 0
                brace_depth = 0
                while j < len(tokens):
                    if tokens[j] == '(':
                        paren_depth += 1
                    elif tokens[j] == ')':
                        paren_depth -= 1
                    elif tokens[j] == '[':
                        bracket_depth += 1
                    elif tokens[j] == ']':
                        bracket_depth -= 1
                    elif tokens[j] == '{':
                        brace_depth += 1
                    elif tokens[j] == '}':
                        brace_depth -= 1
                    elif tokens[j] == ':' and bracket_depth == 0 and paren_depth == 0 and brace_depth == 0:
                        colon_found = True
                        # ':' 后面必须是表达式
                        if j + 1 >= len(tokens):
                            self._error(f'三目运算符 “:” 后面不能为空')
                        next_token = tokens[j + 1]
                        if (next_token in operators or next_token in closing_brackets) and (next_token not in unary_operators):
                            self._error(f'三目运算符 “:” 后面不能是运算符或右括号 “{next_token}”')
                        break
                    j += 1
                if not colon_found:
                    self._error(f'三目运算符 “?” / “|” 后没有找到对应的 “:”')
                i = j + 1
            else:
                i += 1

    def parse_to_tokens(self, code: str) -> List[List[str]]:
        try:
            self._first_validate_syntax(code)
            tokens = self._tokenize(code)
            self._second_validate_syntax(tokens)
            tokens_group = []
            current_group = []
            in_code = 0
            for token in tokens:
                if token == '{':
                    in_code += 1
                if token == '}':
                    in_code -= 1
                if token == ';' and not in_code:
                    if current_group:
                        tokens_group.append(current_group)
                        current_group = []
                else:
                    current_group.append(token)
            if current_group:
                tokens_group.append(current_group)
            return tokens_group
        except tanex_script_error as error_message:
            error(['代码发生了语法错误', str(error_message)])
        except Exception:
            return []
        return []

class parser:
    def __init__(self, line) -> None:
        self.line = line

    def _is_literal(self, token: str) -> Dict[str, Any]:
        # 创建字面量AST节点
        this_type = self._get_token_type(token)
        if this_type == 'string':
            token = f'"{eval(str(token), {})}"'
        return {this_type: token}

    def _parse_brackets(self, tokens: List[str], start: int, end: int, open_bracket: str, close_bracket: str) -> Tuple[Dict[str, Any], int]:
        # 解析括号内容（支持圆括号、方括号、花括号）
        i = start + 1
        # 圆括号作为优先级运算符（最高优先级）
        if open_bracket == '(':
            elements = []
            while i < end and tokens[i] != ')':
                if tokens[i] == ',':
                    error(['( ) 中出现了 “,” 符'])
                expr, i = self._parse_expression(tokens, i, end)
                elements.append(expr)
            if i >= end or tokens[i] != ')':
                raise parse_error(f'未匹配的 {open_bracket} 括号', self.line)
            # 圆括号全部用于优先级控制，直接返回第一个元素（通常只有一个表达式）
            return elements[0] if elements else {}, i + 1
        if open_bracket == '{' and tokens[end - 2] != ';':
            error(['表达式未以分号结尾', f'结束为: {tokens[end - 2]}'])
        # 方括号和花括号作为容器类型
        elements = []
        while i < end and tokens[i] != close_bracket:
            if open_bracket == '{' and tokens[i] == ',':
                error(['{ } 中出现了 “,” 符'])
            if open_bracket == '[' and tokens[i] == ',':
                i += 1
                continue
            # 在花括号中跳过分号（语句分隔符）
            if open_bracket == '{' and tokens[i] == ';':
                i += 1
                continue
            expr, i = self._parse_expression(tokens, i, end)
            elements.append(expr)
            if i < end and tokens[i] == ',' and open_bracket != '{':
                i += 1
        if i >= end or tokens[i] != close_bracket:
            raise parse_error(f'未匹配的 {open_bracket} 括号', self.line)
        bracket_type = 'list' if open_bracket == '[' else 'code'
        return {bracket_type: elements}, i + 1

    def _parse_primary(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析基本表达式：字面量、标识符、括号
        if start >= end:
            raise parse_error('意外的结束符', self.line)
        token = tokens[start]
        # 处理括号表达式
        if token == '(':
            return self._parse_brackets(tokens, start, end, '(', ')')
        elif token == '[':
            return self._parse_brackets(tokens, start, end, '[', ']')
        elif token == '{':
            return self._parse_brackets(tokens, start, end, '{', '}')
        else:
            return self._is_literal(token), start + 1

    def _parse_postfix(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析后缀运算：下标访问、函数调用、点号访问
        expr, pos = self._parse_primary(tokens, start, end)
        while pos < end:
            token = tokens[pos]
            # 下标访问
            if token == '[':
                right = []
                i = pos + 1
                # 空列表
                if i < end and tokens[i] == ']':
                    raise parse_error('空的索引访问', self.line)
                while i < end and tokens[i] != ']':
                    if tokens[i] == ',':
                        i += 1
                        continue
                    value, i = self._parse_expression(tokens, i, end)
                    right.append(value)
                    if i < end and tokens[i] == ',':
                        i += 1
                if i >= end or tokens[i] != ']':
                    raise parse_error('未匹配的 [', self.line)
                # 检查下标访问只能有一个表达式
                if len(right) != 1:
                    raise parse_error('下标访问中出现了 “,” 符', self.line)
                expr = {'subscript': {'left': expr, 'right': right[0]}}
                pos = i + 1
            # 新值获取
            elif token == '{':
                args = []
                i = pos + 1
                # 空列表
                if i < end and tokens[i] == '}':
                    expr = {'new': {'type': expr, 'include': args}}
                    pos = i + 1
                    continue
                while i < end and tokens[i] != '}':
                    if tokens[i] == ';':
                        raise parse_error('未匹配的 {', self.line)
                    if tokens[i] == ',':
                        # 检查下一个位置来确定当前逗号的含义
                        if i + 1 < end and (tokens[i + 1] == ',' or tokens[i + 1] == '}'):
                            # 下一个是逗号或右花括号，说明当前逗号表示空参数
                            args.append({'none_type': 'none'})
                        # 如果args为空，说明这是开括号后的第一个逗号，表示空参数
                        elif len(args) == 0:
                            args.append({'none_type': 'none'})
                        i += 1  # 跳过逗号
                    else:
                        # 正常参数
                        arg, i = self._parse_expression(tokens, i, end)
                        args.append(arg)
                if i >= end or tokens[i] != '}':
                    raise parse_error('未匹配的 {', self.line)
                expr = {'new': {'type': expr, 'include': args}}
                pos = i + 1
            # 函数调用
            elif token == '(':
                args = []
                i = pos + 1
                # 空参数列表
                if i < end and tokens[i] == ')':
                    expr = {'function': {'name': expr, 'arg': args}}
                    pos = i + 1
                    continue
                # 解析参数
                while i < end and tokens[i] != ')':
                    if tokens[i] == ',':
                        # 检查下一个位置来确定当前逗号的含义
                        if i + 1 < end and (tokens[i + 1] == ',' or tokens[i + 1] == ')'):
                            # 下一个是逗号或右括号，说明当前逗号表示空参数
                            args.append({'none_type': 'none'})
                        # 如果args为空，说明这是开括号后的第一个逗号，表示空参数
                        elif len(args) == 0:
                            args.append({'none_type': 'none'})
                        i += 1  # 跳过逗号
                    else:
                        # 正常参数
                        arg, i = self._parse_expression(tokens, i, end)
                        args.append(arg)
                if i >= end or tokens[i] != ')':
                    raise parse_error('未匹配的 (', self.line)
                expr = {'function': {'name': expr, 'arg': args}}
                pos = i + 1
            # 点号访问 (属性/方法访问)
            elif token == '.':
                if pos + 1 >= end:
                    raise parse_error('点号访问需要后跟标识符', self.line)
                member_token = tokens[pos + 1]
                member_expr = self._is_literal(member_token)
                expr = {'member': {'left': expr, 'right': member_expr}}
                pos = pos + 2
            else:
                break
        return expr, pos

    def _parse_unary(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析一元运算符和后缀访问
        if start >= end:
            raise parse_error('意外的结束符', self.line)
        token = tokens[start]
        if token in ['!', '*', '**', '***', '+', '-', '&', '/', '~', '->', 'not', 'return', '$', '@', '<-']:
            if token == 'not':
                token = '!'
            if token == 'return':
                token = '$'
            operand, pos = self._parse_unary(tokens, start + 1, end)
            return {'unary': [token, operand]}, pos
        else:
            return self._parse_postfix(tokens, start, end)

    def _parse_anonymous_function(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析匿名函数与循环符
        expr, pos = self._parse_unary(tokens, start, end)
        while pos < end and tokens[pos] in ['::', '$$']:
            operator = tokens[pos]
            operand, new_pos = self._parse_unary(tokens, pos + 1, end)
            expr = {'binary': [operator, expr, operand]}
            pos = new_pos
        return expr, pos

    def _parse_factor(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析乘除运算（优先级高于加减）
        expr, pos = self._parse_anonymous_function(tokens, start, end)
        while pos < end and tokens[pos] in ['*', '/', '\\', '%', '^']:
            operator = tokens[pos]
            operand, new_pos = self._parse_anonymous_function(tokens, pos + 1, end)
            expr = {'binary': [operator, expr, operand]}
            pos = new_pos
        return expr, pos

    def _parse_term(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析加减运算
        expr, pos = self._parse_factor(tokens, start, end)
        while pos < end and tokens[pos] in ['+', '-']:
            operator = tokens[pos]
            operand, new_pos = self._parse_factor(tokens, pos + 1, end)
            expr = {'binary': [operator, expr, operand]}
            pos = new_pos
        return expr, pos

    def _parse_comparison(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析比较运算与 `in`
        expr, pos = self._parse_term(tokens, start, end)
        while pos < end and tokens[pos] in ['<', '<=', '>', '>=', '==', '!=', 'is', 'in']:
            operator = tokens[pos]
            operand, new_pos = self._parse_term(tokens, pos + 1, end)
            expr = {'binary': [operator, expr, operand]}
            pos = new_pos
        return expr, pos

    def _parse_logical(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析逻辑运算
        expr, pos = self._parse_comparison(tokens, start, end)
        while pos < end and tokens[pos] in ['&&', '||', 'and', 'or']:
            if tokens[pos] in ['and', 'or']:
                tokens[pos] = '&&' if tokens[pos] == 'and' else '||'
            operator = tokens[pos]
            operand, new_pos = self._parse_comparison(tokens, pos + 1, end)
            expr = {'binary': [operator, expr, operand]}
            pos = new_pos
        return expr, pos

    def _parse_input_and_output(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析 输入/出 符
        expr, pos = self._parse_logical(tokens, start, end)
        while pos < end and tokens[pos] in ['<<', '>>']:
            operator = tokens[pos]
            operand, new_pos = self._parse_logical(tokens, pos + 1, end)
            expr = {'binary': [operator, expr, operand]}
            pos = new_pos
        return expr, pos

    def _parse_ternary(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析三目运算符
        expr, pos = self._parse_input_and_output(tokens, start, end)
        # 检查是否有三目运算符
        if pos < end and tokens[pos] in ['?', '|']:
            # 保存三目运算符类型
            ternary_op = tokens[pos]
            # 直接使用当前pos位置的运算符
            # 解析条件
            condition = expr
            pos += 1
            # 跳过 '?' / '|'
            # 解析真值表达式
            true_expr, pos = self._parse_input_and_output(tokens, pos, end)
            if list(true_expr.keys())[0] == 'unknown':
                raise parse_error('三目运算符 “?” / “|” 后没有值', self.line)
            # 检查 ':' 运算符
            if pos >= end or tokens[pos] != ':':
                raise parse_error('三目运算符中缺少 “:”', self.line)
            pos += 1  # 跳过 ':'
            # 解析假值表达式
            false_expr, pos = self._parse_input_and_output(tokens, pos, end)
            # 构建三目运算符的 AST
            expr = {'ternary': {'operator': ternary_op, 'condition': condition, 'true': true_expr, 'false': false_expr}}
        return expr, pos

    def _parse_expression(self, tokens: List[str], start: int, end: int) -> Tuple[Dict[str, Any], int]:
        # 解析完整表达式
        expr, pos = self._parse_ternary(tokens, start, end)
        # 处理赋值运算符（包括复合赋值）
        if pos < end:
            operator = tokens[pos]
            # 检查是否为赋值运算符（以=结尾或者本身就是=）
            if operator == '=' or (len(operator) == 2 and operator.endswith('=') and operator != '=='):
                operand, new_pos = self._parse_expression(tokens, pos + 1, end)
                expr = {'assignment': {'operator': operator, 'left': expr, 'right': operand}}
                pos = new_pos
        return expr, pos

    def parse(self, tokens: List[str]) -> Dict[str, Any]:
        if not tokens:
            return {}
        try:
            ast, pos = self._parse_expression(tokens, 0, len(tokens))
            if pos < len(tokens):
                error([f'多余的代码: {' '.join(tokens)}'])
            else:
                return ast
        except tanex_script_error as error_msg:
            error(['代码的语法错误', str(error_msg)])
        except Exception as e:
            print(str(e))
        return {}

    def _get_token_type(self, token: str) -> str:
        # 获取 token 的类型
        if token.startswith("'") and token.endswith("'"):
            return 'number'
        elif token.startswith('"') and token.endswith('"'):
            return 'string'
        elif token.startswith('`') and token.endswith('`'):
            return 'address'
        elif token in ['true', 'false']:
            return 'boolean'
        elif token in ('nan', 'infinite', 'none'):
            return f'{token}_type'
        elif re.match(r'^(?:[a-zA-Z0-9_]|[\u0370-\u03ff]|[\u0400-\u04ff]|[\u0590-\u05ff]|[\u0600-\u06ff]|[\u0e00-\u0e7f]|[\u0900-\u097f]|[\u4e00-\u9fff]|[\u3040-\u309f]|[\u30a0-\u30ff]|[\uac00-\ud7af]|[\u00c0-\u024f]|[\u1e00-\u1eff]|[\u2c60-\u2c7f]|[\ua720-\ua7ff])*$', token):
            return 'name'
        else:
            return 'unknown'

def code_to_json(path) -> Dict[str, Any]:
    def process_path_improved(original_path: str) -> str:
        # 使用 os.path.splitext 分离文件扩展名
        name_without_ext, ext = os.path.splitext(original_path)
        # 如果是 .tsucc 文件，使用 .tscc 作为新扩展名
        if ext.lower() != '.tsucc':
            # 如果不是 .tsucc 文件，给出建议但仍输出结果
            warning(['输入文件不是 .tsucc 后缀', '输入文件', [name_without_ext + ext]])
        return name_without_ext + '.tscc'

    if not os.path.exists(path):
        error([f'路径 {path} 不存在'])
    with open(path, 'r', encoding = 'utf-8') as file:
        content = file.read()
        path = process_path_improved(path)
        # 将代码转换为 JSON 格式的 AST
        tokenizer = lexer()
        tokens = tokenizer.parse_to_tokens(content)
        i = 0
        return_list = []
        for this_tokens in tokens:
            i += 1
            parse = parser(i)
            ast = parse.parse(this_tokens)
            return_list += [ast]
        return_value = {'Tanex Script': return_list}
        with open(path, 'w', encoding = 'utf-8') as file:
            content = file.write(json.dumps(return_value, indent = 4, ensure_ascii = False))
        return return_value

__all__ = ['code_to_json']
