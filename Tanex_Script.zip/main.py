import sys
import os

sys.path.append(os.path.dirname(__file__))

from define import *
from tanex_script_compile import *
from tanex_script_run_time import *

def main():
    try:
        if len(sys.argv) != 2:
            exit(1)
        file_path = sys.argv[1]
        code_to_json(file_path)
        run_code(file_path)
    except tanex_script_error as e:
        error([str(e)])
    except Exception:
        exit(1)

if __name__ == '__main__':
    main()
