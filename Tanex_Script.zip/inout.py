# Tanex Script 输入输出模块
# 提供 Tanex Script 语言的输入输出功能
# 包括自定义的输入函数和格式化输出函数

from define import hex_to_ansi
from tanex_script_compile import tanex_script_error

def tanex_script_input():
    return f"\"{input()}\""

def tanex_script_output(string):
    def output_value(s):
        if not s:
            return None
        match s[0]:
            case 'c':
                print(hex_to_ansi(s[1:-2]), end = '')
            case '_':
                print(' ', end = '')
            case '%':
                print('%', end = '')
            case _:
                raise tanex_script_error(f'% 不能处理 {s[0]}')

    flag, c, i = False, '', 0
    while i < len(string):
        c = string[i]
        if c != '%':
            if not flag:
                print(c, end = '')
            else:
                try:
                    index = string.index(';')
                except:
                    raise tanex_script_error('未找到 % 的结束符 ;')
                print(output_value(string[i:index + 1]), end = '')
                flag, i = False, index - 1
        else:
            if not flag:
                flag = True
            else:
                print('%', end = '')
                flag = False
        i += 1

if __name__ == '__main__':
    tanex_script_output(tanex_script_input())
